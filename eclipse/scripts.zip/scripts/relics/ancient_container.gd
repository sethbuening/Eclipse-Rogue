class_name AncientContainer
extends Node2D

@export var relic: RelicData = null

const INTERACT_RADIUS: float = 20.0

var _player: CharacterBody2D = null
var _label:  Label           = null

func _ready() -> void:
	_player = get_tree().get_first_node_in_group("player")
	# Placeholder visual — replace sprite texture in editor
	var sprite        := Sprite2D.new()
	sprite.z_index     = 0   # relative to parent's -4095
	sprite.modulate    = Color(0.8, 0.7, 0.4)
	# 1×1 white pixel scaled up as placeholder until you have art
	var img := Image.create(1, 1, false, Image.FORMAT_RGBA8)
	img.set_pixel(0, 0, Color.WHITE)
	sprite.texture = ImageTexture.create_from_image(img)
	sprite.scale   = Vector2(20, 12)
	add_child(sprite)

	_label          = Label.new()
	_label.text     = "[E] Collect"
	_label.position = Vector2(-24, -20)
	_label.visible  = false
	_label.z_index  = 4096
	_label.z_as_relative = false
	add_child(_label)

func _process(_delta: float) -> void:
	if _player == null:
		return
	var dist: float = global_position.distance_to(_player.global_position)
	var nearby: bool = dist <= INTERACT_RADIUS
	_label.visible = nearby
	if nearby and Input.is_action_just_pressed("interact"):
		_collect()

func _collect() -> void:
	if relic == null:
		return
	_player.get_node("Inventory").add_relic(relic, 1)
	RelicPopup.display(relic)
	queue_free()
