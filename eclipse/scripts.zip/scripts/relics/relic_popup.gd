class_name RelicPopup
extends CanvasLayer

const DURATION:     float = 4.0
const FADE_START:   float = 3.0

var _timer:  float   = 0.0
var _active: bool    = false

@onready var panel:      PanelContainer = $Panel
@onready var name_label: Label          = $Panel/VBox/NameLabel
@onready var desc_label: Label          = $Panel/VBox/DescLabel

func _ready() -> void:
	panel.hide()

func display(relic: RelicData) -> void:
	name_label.text   = relic.display_name
	desc_label.text   = relic.description
	panel.modulate.a  = 1.0
	panel.show()
	_timer  = 0.0
	_active = true

func _process(delta: float) -> void:
	if not _active:
		return
	_timer += delta
	if _timer >= FADE_START:
		panel.modulate.a = 1.0 - (_timer - FADE_START) / (DURATION - FADE_START)
	if _timer >= DURATION:
		_active = false
		panel.hide()
		panel.modulate.a = 1.0
