# ability_midas_curse.gd
# ---------------------------------------------------------------------------
# Periodically marks the highest-health enemy.  Marked enemies take increased
# crit chance and crit damage.  Only one mark at a time (plus an optional
# bonus mark from Jackpot Wheel).
#
# Mark migration
#   When the marked enemy dies, the mark leaps instantly to the next highest-
#   health enemy with no gap.  Against a boss with adds, killing an add
#   immediately redirects pressure.  The mark is never "wasted."
#
# Cursed death bonus
#   If the marked enemy dies to a non-crit (from any damage source including
#   Lightning), Midas Curse generates a Fortune burst equal to half of a
#   normal crit's Fortune yield.  This creates a cross-metal incentive:
#   you want Lightning to finish off marked enemies you couldn't crit,
#   because the curse still pays out.
#
# Gold synergies
#   → Gilded Shot  : marked enemies grant bonus Fortune on any hit.
#   → Rain of Crowns: Crowns prioritize the marked enemy.
#   ← Jackpot Wheel : BONUS_MARK outcome creates a second simultaneous mark.
# ---------------------------------------------------------------------------
class_name AbilityMidasCurse
extends AbilityData

var _cooldown_accum: float = 0.0
var _connected:      bool  = false

func tick(context: Dictionary) -> void:
	super.tick(context)
	var player: CharacterBody2D = context["player"]
	var delta:  float           = context.get("delta", 0.0)

	# Connect to death signal once.
	if not _connected:
		_connected = true
		if not EnemyManager.enemy_died.is_connected(_on_enemy_died):
			EnemyManager.enemy_died.connect(_on_enemy_died)

	# If the current mark is stale, migrate immediately.
	if is_instance_valid(GoldState.marked_enemy):
		# Apply visual mark meta to enemy so other systems can read it.
		GoldState.marked_enemy.set_meta("midas_marked", true)
		GoldState.marked_enemy.set_meta("midas_crit_chance_bonus",
			get_stat("curse_crit_chance_bonus") if get_stat("curse_crit_chance_bonus") > 0.0 else 0.25)
		GoldState.marked_enemy.set_meta("midas_crit_damage_bonus",
			get_stat("curse_crit_damage_bonus") if get_stat("curse_crit_damage_bonus") > 0.0 else 0.5)
	else:
		_cooldown_accum += delta

	var cooldown: float = get_stat("curse_mark_interval")
	if cooldown <= 0.0:
		cooldown = 5.0

	if _cooldown_accum < cooldown:
		# Orb glow shows mark cooldown progress.
		context["orb_t"] = _cooldown_accum / cooldown
		return

	_cooldown_accum = 0.0
	_place_new_mark()

	# Jackpot Wheel: BONUS_MARK gives a second temporary mark.
	if GoldState.wheel_ready and GoldState.wheel_outcome == GoldState.WheelOutcome.BONUS_MARK:
		GoldState.consume_wheel_outcome()
		GoldState.bonus_mark_active  = true
		GoldState.get("_bonus_mark_timer")  # access to set below
		# Can't assign private directly — bonus_mark_active flag is enough for
		# Rain of Crowns and Gilded Shot to react; timer ticks in GoldState.tick().

	context["orb_t"]     = 1.0
	context["activated"] = true
	stats.apply_to_player(player)

func _place_new_mark() -> void:
	var best:        Enemy = null
	var best_health: int   = -1
	for enemy: Enemy in EnemyManager.living_enemies:
		if not is_instance_valid(enemy):
			continue
		if enemy.health > best_health:
			best_health = enemy.health
			best        = enemy
	if best == null:
		return

	# Clear old mark meta.
	if is_instance_valid(GoldState.marked_enemy):
		GoldState.marked_enemy.remove_meta("midas_marked")
		GoldState.marked_enemy.remove_meta("midas_crit_chance_bonus")
		GoldState.marked_enemy.remove_meta("midas_crit_damage_bonus")

	GoldState.place_mark(best)
	ParticleManager.spawn_gold_bomb_trail(best.global_position)

func _on_enemy_died(enemy: Enemy) -> void:
	if enemy != GoldState.marked_enemy:
		return

	# Cursed death bonus: if killed without a crit, pay out partial Fortune.
	if not enemy.has_meta("killed_by_crit"):
		# Fortune burst for killing the mark without critting it.
		# We need the player reference — find it via EnemyManager.
		var player: CharacterBody2D = EnemyManager.player
		if player != null:
			var power: float = stats.get_stat("power", _orb_potency, [])
			GoldState.add_fortune(power * 0.5, player)

	# Clear mark meta.
	if is_instance_valid(enemy):
		if enemy.has_meta("midas_marked"):
			enemy.remove_meta("midas_marked")
		if enemy.has_meta("midas_crit_chance_bonus"):
			enemy.remove_meta("midas_crit_chance_bonus")
		if enemy.has_meta("midas_crit_damage_bonus"):
			enemy.remove_meta("midas_crit_damage_bonus")

	# Immediately migrate the mark — no cooldown gap.
	_place_new_mark()
