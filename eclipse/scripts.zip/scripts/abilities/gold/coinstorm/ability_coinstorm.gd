# ability_coinstorm.gd
# ---------------------------------------------------------------------------
# Auto-fires a radial spray of spinning coins outward in all directions.
# Strong against crowds. Each coin rolls crit independently.
#
# Fortune-scaling radius
#   Coinstorm spends Fortune on fire: the more Fortune available, the wider
#   the spray.  It is both a Fortune consumer and generator — early volleys
#   build Fortune, which makes later volleys wider, which hit more enemies,
#   which build Fortune faster.  At zero Fortune the spray barely clears
#   melee range; at max Fortune it covers nearly the full screen.
#
# Gold synergies
#   → Fortune Engine : many independent crit rolls per volley rapidly fill
#                      Engine stacks on failures.
#   → King's Treasury: against dense crowds can fill Treasury in one volley.
#   ← Jackpot Wheel  : EXTRA_COINSTORM outcome doubles projectile_count for
#                      the next volley only.
#
# Cross-metal synergy (StaticField)
#   Every crit calls StaticField.consume_at() via GoldState.on_gold_crit().
# ---------------------------------------------------------------------------
class_name AbilityCoinstorm
extends AbilityData

const CoinScene := preload("res://scenes/abilities/gold_coin.tscn")

# Fraction of current Fortune spent on each volley to expand radius.
const FORTUNE_SPEND_FRACTION: float = 0.15
# How much the radius grows per 100 Fortune spent (added to base aoe_radius).
const RADIUS_PER_FORTUNE:     float = 0.8

func tick(context: Dictionary) -> void:
	super.tick(context)
	var player:      Node2D = context["player"]
	var orb_potency: float  = context.get("orb_potency", 1.0)

	if EnemyManager.living_enemies.is_empty():
		return

	var orb_index: int     = context.get("orb_index", -1)
	var orb_spawn: Vector2 = player.global_position
	if orb_index >= 0 and orb_index < player.orb_visuals.size():
		orb_spawn = player.orb_visuals[orb_index].sprite.global_position

	# Spend Fortune to determine spread radius.
	var fortune_to_spend: float = GoldState.fortune * FORTUNE_SPEND_FRACTION
	var spent:            float = GoldState.spend_fortune(fortune_to_spend)
	var base_radius:      float = get_stat("aoe_radius")
	if base_radius <= 0.0:
		base_radius = 40.0
	var spread_radius: float = base_radius + spent * RADIUS_PER_FORTUNE

	# Jackpot Wheel: EXTRA_COINSTORM doubles count for this volley.
	var count: int = maxi(1, int(get_stat("projectile_count")))
	if GoldState.wheel_ready and GoldState.wheel_outcome == GoldState.WheelOutcome.EXTRA_COINSTORM:
		GoldState.consume_wheel_outcome()
		count *= 2

	# Fire coins evenly distributed around a full circle.
	var angle_step: float = TAU / float(count)
	for i: int in range(count):
		var angle: float = angle_step * i + randf_range(-0.05, 0.05)   # slight jitter
		var dir:   Vector2 = Vector2.RIGHT.rotated(angle)
		var coin := CoinScene.instantiate() as Coin
		player.get_parent().add_child(coin)
		coin.global_position = orb_spawn
		coin.launch(dir, spread_radius, stats, orb_potency, main_stats, player)

	# Drive orb glow from Fortune level.
	context["orb_t"]     = GoldState.fortune / GoldState.fortune_capacity
	context["activated"] = true
	stats.apply_to_player(player)
