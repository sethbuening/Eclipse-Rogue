# ability_gilded_shot.gd
# ---------------------------------------------------------------------------
# Auto-fires toward the nearest enemy on cooldown.  High base crit chance.
# The backbone of the Gold kit — the only ability with no special trigger condition.
#
# Overshoot mechanic
#   The projectile continues past its primary target by a fixed distance.
#   During the overshoot, it hits nearby enemies at reduced crit chance.
#   Positioning the player so targets have enemies behind them is the main
#   skill expression.
#
# Gold synergies
#   → King's Treasury : crits call GoldState.on_gold_crit() → treasury fill.
#   → Midas Curse     : any hit against the marked enemy generates bonus
#                       Fortune (non-crits too); crits generate extra Fortune.
#
# Cross-metal synergy (StaticField)
#   GoldState.on_gold_crit() calls StaticField.consume_at() on every crit.
#   A field-amplified crit also has a larger crit_mult, so Fortune gain
#   compounds — the two metals reinforce each other.
# ---------------------------------------------------------------------------
class_name AbilityGildedShot
extends AbilityData

const GildedShotScene := preload("res://scenes/abilities/gilded_shot.tscn")

func tick(context: Dictionary) -> void:
	super.tick(context)
	var player:      Node2D = context["player"]
	var orb_potency: float  = context.get("orb_potency", 1.0)

	var result: Util.TargetingResult = Targeting.nearest_enemy(player, get_stat("range"))
	if not result.found:
		return

	var orb_index: int     = context.get("orb_index", -1)
	var orb_spawn: Vector2 = player.global_position
	if orb_index >= 0 and orb_index < player.orb_visuals.size():
		orb_spawn = player.orb_visuals[orb_index].sprite.global_position

	var shot := GildedShotScene.instantiate() as GildedShot
	player.get_parent().add_child(shot)
	shot.global_position = orb_spawn
	shot.launch(result.targets[0] as Enemy, stats, orb_potency, main_stats, player)

	context["orb_t"]     = 1.0
	context["activated"] = true
	stats.apply_to_player(player)
