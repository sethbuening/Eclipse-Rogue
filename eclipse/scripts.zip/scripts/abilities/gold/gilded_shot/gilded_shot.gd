# gilded_shot.gd
# ---------------------------------------------------------------------------
# Projectile for AbilityGildedShot.
# Phase 1: travels to primary target, deals a normal (possibly critting) hit.
# Phase 2 (overshoot): continues past the primary along the same axis,
#   hitting nearby enemies at reduced crit chance until it exhausts its range.
# ---------------------------------------------------------------------------
class_name GildedShot
extends Node2D

const TRAVEL_SPEED:         float = 480.0
const OVERSHOOT_DISTANCE:   float = 80.0
const OVERSHOOT_HIT_RADIUS: float = 14.0
const OVERSHOOT_CRIT_SCALE: float = 0.4   # crit_chance multiplier during overshoot

var _stats:       AbilityStats
var _orb_potency: float
var _main_stats:  Array[String]
var _player:      CharacterBody2D

var _primary:          Enemy          = null
var _primary_hit:      bool           = false
var _direction:        Vector2        = Vector2.RIGHT
var _overshoot_end:    Vector2        = Vector2.ZERO
var _overshoot_hit:    Array[Enemy]   = []

func _ready() -> void:
	set_physics_interpolation_mode(Node.PHYSICS_INTERPOLATION_MODE_OFF)

func launch(
	primary:     Enemy,
	ability_stats: AbilityStats,
	orb_potency: float,
	main_stats:  Array[String],
	player:      CharacterBody2D
) -> void:
	_stats       = ability_stats
	_orb_potency = orb_potency
	_main_stats  = main_stats
	_player      = player
	_primary     = primary
	_direction   = (primary.global_position - global_position).normalized()
	_overshoot_end = primary.global_position + _direction * OVERSHOOT_DISTANCE
	reset_physics_interpolation()

func _process(delta: float) -> void:
	var step: float = TRAVEL_SPEED * delta
	global_position += _direction * step

	if not _primary_hit:
		# Arrive at primary?
		var target_pos: Vector2 = _primary.global_position if is_instance_valid(_primary) else _overshoot_end
		if global_position.distance_to(target_pos) <= step + 2.0:
			if is_instance_valid(_primary):
				_deal_hit(_primary, _stats.crit_chance)
			_primary_hit = true
	else:
		# Overshoot: check all nearby enemies.
		var r2: float = OVERSHOOT_HIT_RADIUS * OVERSHOOT_HIT_RADIUS
		for enemy: Enemy in EnemyManager.living_enemies:
			if not is_instance_valid(enemy) or enemy == _primary or enemy in _overshoot_hit:
				continue
			if global_position.distance_squared_to(enemy.global_position) <= r2:
				_overshoot_hit.append(enemy)
				_deal_hit(enemy, _stats.crit_chance * OVERSHOOT_CRIT_SCALE)

		if global_position.distance_to(_overshoot_end) <= step + 2.0:
			queue_free()

func _deal_hit(enemy: Enemy, effective_crit_chance: float) -> void:
	var power: float = _stats.get_stat("power", _orb_potency, _main_stats)

	# Roll crit — guaranteed_crits takes priority, then use effective_crit_chance.
	var is_crit: bool = false
	if _player != null and _player.guaranteed_crits > 0:
		_player.guaranteed_crits -= 1
		is_crit = true
	else:
		is_crit = randf() < effective_crit_chance

	# Midas mark: bonus Fortune on any hit; extra on crits.
	if is_instance_valid(GoldState.marked_enemy) and enemy == GoldState.marked_enemy:
		GoldState.add_fortune(power * 0.08, _player)

	if is_crit:
		var crit_mult: float = _resolve_crit_mult()
		# Apply Midas Curse crit damage bonus.
		if is_instance_valid(GoldState.marked_enemy) and enemy == GoldState.marked_enemy:
			crit_mult *= 1.0 + _stats.get_stat("curse_crit_damage_bonus", _orb_potency, _main_stats)
			GoldState.add_fortune(power * 0.12, _player)   # extra Fortune for critting a marked enemy
		var damage: float = power * crit_mult
		var engine_bonus: float = GoldState.on_gold_crit(
			enemy.global_position, crit_mult, StaticField.TRIGGER_RADIUS, _player
		)
		damage *= engine_bonus
		enemy.take_damage(int(damage), _stats.get_armor_pen(), true, Util.DamageType.PHYSICAL)
	else:
		GoldState.engine_stacks = mini(GoldState.engine_stacks + 1, GoldState.engine_stack_cap)
		enemy.take_damage(int(power), _stats.get_armor_pen(), false, Util.DamageType.PHYSICAL)

	_apply_hit_effects(enemy)
	ParticleManager.spawn_gold_bomb_trail(enemy.global_position)

## Apply Wheel outcome to a crit multiplier.  Outcomes not relevant to
## Gilded Shot are put back for the next ability to claim.
func _resolve_crit_mult() -> float:
	if not GoldState.wheel_ready:
		return _stats.crit_damage
	var outcome: GoldState.WheelOutcome = GoldState.consume_wheel_outcome()
	match outcome:
		GoldState.WheelOutcome.DOUBLE_CRIT:
			return _stats.crit_damage * 2.0
		GoldState.WheelOutcome.TRIPLE_CRIT:
			return _stats.crit_damage * 3.0
		GoldState.WheelOutcome.FORTUNE_BURST:
			GoldState.add_fortune(60.0, _player)
			return _stats.crit_damage
		GoldState.WheelOutcome.GUARANTEED_CRITS:
			if _player != null:
				_player.guaranteed_crits += 4
			return _stats.crit_damage
		_:
			# Not for us — restore for whoever can use it.
			GoldState.wheel_outcome = outcome
			GoldState.wheel_ready   = true
			return _stats.crit_damage

func _apply_hit_effects(enemy: Enemy) -> void:
	if not is_instance_valid(enemy):
		return
	if _stats.knockback > 0.0:
		var dir: Vector2 = (enemy.global_position - global_position).normalized()
		if enemy.has_method("apply_knockback"):
			enemy.apply_knockback(dir * _stats.knockback)
	if _stats.stun_duration > 0.0 and enemy.has_method("apply_stun"):
		enemy.apply_stun(_stats.stun_duration)
	if _stats.slow_amount > 0.0 and enemy.has_method("apply_slow"):
		enemy.apply_slow(_stats.slow_amount, _stats.slow_duration)
