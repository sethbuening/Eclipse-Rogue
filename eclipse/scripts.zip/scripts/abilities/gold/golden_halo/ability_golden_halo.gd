# ability_golden_halo.gd
# ---------------------------------------------------------------------------
# A ring of golden coins orbits the player, damaging enemies on contact.
# High hit frequency — excellent for close-range play and sustaining Fortune.
#
# Fortune-scaling radius
#   The ring radius linearly interpolates between halo_min_radius and
#   halo_max_radius based on current Fortune / fortune_capacity.
#
#   Low Fortune  → tight ring (enemies must come close → builds Fortune fast).
#   High Fortune → wide ring (intercepts enemies at range → sustains Fortune).
#
#   This makes the Halo self-regulating: it is never useless and never free.
#
# Gold synergies
#   → Fortune Engine  : rapid contact hits generate failed-crit stacks.
#   → King's Treasury : while surrounded, high hit frequency charges Treasury.
# ---------------------------------------------------------------------------
class_name AbilityGoldenHalo
extends AbilityData

# The halo is implemented as a lightweight per-frame radius check rather
# than physics, consistent with Ball Lightning's pulse approach.

# How often (seconds) to check for enemies inside the current radius.
const HIT_INTERVAL: float = 0.12

var _hit_timer:  float = 0.0
var _hit_enemies: Array[Enemy] = []   # enemies hit this pulse (cleared each interval)

func tick(context: Dictionary) -> void:
	super.tick(context)
	var player:      Node2D = context["player"]
	var orb_potency: float  = context.get("orb_potency", 1.0)
	var delta:       float  = context.get("delta", 0.0)

	_hit_timer += delta
	if _hit_timer < HIT_INTERVAL:
		context["orb_t"] = _hit_timer / HIT_INTERVAL
		return

	_hit_timer = 0.0
	_hit_enemies.clear()

	# Compute current radius from Fortune level.
	var fortune_t: float  = clampf(GoldState.fortune / GoldState.fortune_capacity, 0.0, 1.0)
	var min_r:     float  = get_stat("halo_min_radius")
	var max_r:     float  = get_stat("halo_max_radius")
	if min_r <= 0.0: min_r = 28.0
	if max_r <= 0.0: max_r = 96.0

	# During Royal Wealth the Halo locks to max radius.
	var radius: float = lerp(min_r, max_r, fortune_t) if not GoldState.royal_wealth_active else max_r
	var r2:     float = radius * radius

	var orb_potency_val: float = orb_potency
	var power: float = stats.get_stat("power", orb_potency_val, main_stats)

	for enemy: Enemy in EnemyManager.living_enemies:
		if not is_instance_valid(enemy):
			continue
		var dist_sq: float = player.global_position.distance_squared_to(enemy.global_position)
		if dist_sq > r2:
			continue

		_hit_enemies.append(enemy)
		var is_crit: bool = stats.roll_crit(player)

		if is_crit:
			var crit_mult:    float = stats.crit_damage
			var damage:       float = power * crit_mult
			var engine_bonus: float = GoldState.on_gold_crit(
				enemy.global_position, crit_mult, StaticField.TRIGGER_RADIUS, player
			)
			damage *= engine_bonus
			enemy.take_damage(int(damage), stats.get_armor_pen(), true, Util.DamageType.PHYSICAL)
		else:
			GoldState.engine_stacks = mini(
				GoldState.engine_stacks + 1, GoldState.engine_stack_cap
			)
			enemy.take_damage(int(power), stats.get_armor_pen(), false, Util.DamageType.PHYSICAL)

		ParticleManager.spawn_gold_bomb_trail(enemy.global_position)

	# Orb glow scales with Fortune (shows ring size state to player).
	context["orb_t"] = fortune_t
