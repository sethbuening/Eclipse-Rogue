# ability_fortune_engine.gd
# ---------------------------------------------------------------------------
# Passive.  Tracks failed crits across all Gold abilities.  Each failed
# crit increments engine_stacks in GoldState (written by every Gold ability
# on non-crits).  When any Gold ability crits, GoldState.on_gold_crit()
# consumes all stacks and returns an engine_bonus multiplier — this ability
# doesn't need to do anything except configure the cap and wire Rain of Crowns.
#
# Stack cap scales with current Fortune
#   At low Fortune the cap is small — the Engine is less volatile.
#   At high Fortune the cap rises — a lucky crit into a high-Fortune state
#   can land an enormous single hit.
#   Formula: cap = engine_base_stack_cap + floor(fortune * engine_stacks_per_fortune / 100)
#
# Gold synergies
#   → Rain of Crowns : Crowns consume Engine stacks on impact for bonus
#                      damage and increased crater radius.  Wired by Rain of
#                      Crowns reading GoldState.engine_stacks before impact.
#   → Jackpot Wheel  : high Engine charge (>= 80% of cap) biases the Wheel
#                      toward jackpot outcomes.
# ---------------------------------------------------------------------------
class_name AbilityFortuneEngine
extends AbilityData

const CAP_UPDATE_INTERVAL: float = 0.1   # recalculate cap this often
var _cap_timer: float = 0.0

func tick(context: Dictionary) -> void:
	super.tick(context)
	var orb_potency: float = context.get("orb_potency", 1.0)
	var delta:       float = context.get("delta", 0.0)

	_cap_timer += delta
	if _cap_timer >= CAP_UPDATE_INTERVAL:
		_cap_timer = 0.0
		_recalculate_cap(orb_potency)

	# Orb glow shows how full the Engine is.
	var cap: int = maxi(1, GoldState.engine_stack_cap)
	context["orb_t"] = clampf(float(GoldState.engine_stacks) / float(cap), 0.0, 1.0)

func _recalculate_cap(orb_potency: float) -> void:
	var base:            int   = int(get_stat("engine_base_stack_cap"))
	var per_fortune:     float = get_stat("engine_stacks_per_fortune")
	if base         <= 0: base         = 6
	if per_fortune  <= 0.0: per_fortune = 0.04   # +1 cap per 25 Fortune

	var fortune_bonus: int = int(GoldState.fortune * per_fortune)
	GoldState.engine_stack_cap = base + fortune_bonus
