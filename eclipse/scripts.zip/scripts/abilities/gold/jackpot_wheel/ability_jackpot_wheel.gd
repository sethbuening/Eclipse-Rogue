# ability_jackpot_wheel.gd
# ---------------------------------------------------------------------------
# Passive.  Spins a hidden wheel on a fixed interval.  The NEXT Gold ability
# to crit after a spin receives the outcome.  Outcomes are not revealed until
# the triggering crit lands — the player sees a "spin ready" indicator but
# not the result.  Positioning to guarantee the next hit is a crit (e.g.
# firing at a Midas-marked enemy) is the high-skill interaction.
#
# Outcome table is biased by Fortune Engine charge
#   engine_stacks near cap → jackpot outcomes are more likely.
#   Low engine / low fortune → minor outcomes.
#
# WheelOutcomes are processed by whichever Gold ability lands the triggering
# crit (via _resolve_crit_mult() helpers in each projectile/attack script).
# Outcomes not consumed by the triggering ability are put back for the next.
#
# Gold synergies
#   → Coinstorm    : EXTRA_COINSTORM doubles projectile count for next volley.
#   → Midas Curse  : BONUS_MARK creates a second temporary mark.
#   → Gilded Shot  : GUARANTEED_CRITS and crit-mult outcomes apply here.
#   ← Fortune Engine: high Engine charge biases the table toward jackpots.
# ---------------------------------------------------------------------------
class_name AbilityJackpotWheel
extends AbilityData

var _spin_timer: float = 0.0

func tick(context: Dictionary) -> void:
	super.tick(context)
	var delta: float = context.get("delta", 0.0)

	if GoldState.wheel_ready:
		# Waiting for a crit to consume it — show full glow.
		context["orb_t"] = 1.0
		return

	_spin_timer += delta
	var interval: float = get_stat("wheel_spin_interval")
	if interval <= 0.0:
		interval = 5.0

	context["orb_t"] = clampf(_spin_timer / interval, 0.0, 1.0)

	if _spin_timer < interval:
		return

	_spin_timer = 0.0
	_spin()

func _spin() -> void:
	var outcome: GoldState.WheelOutcome = _roll_outcome()
	GoldState.wheel_outcome = outcome
	GoldState.wheel_ready   = true
	GoldState.emit_signal("wheel_spun", outcome)

func _roll_outcome() -> GoldState.WheelOutcome:
	var cap:    int   = maxi(1, GoldState.engine_stack_cap)
	var stacks: int   = GoldState.engine_stacks
	# engine_charge_t: 0.0 = empty, 1.0 = full cap
	var engine_charge_t: float = clampf(float(stacks) / float(cap), 0.0, 1.0)

	# Build a weighted table.  Jackpot outcomes have base weight 1;
	# at max engine charge they have weight 6.
	var jackpot_w: float = lerp(1.0, 6.0, engine_charge_t)
	var minor_w:   float = lerp(6.0, 1.0, engine_charge_t)

	var table: Array = [
		{ "outcome": GoldState.WheelOutcome.DOUBLE_CRIT,       "weight": lerp(4.0, 2.0, engine_charge_t) },
		{ "outcome": GoldState.WheelOutcome.TRIPLE_CRIT,       "weight": jackpot_w },
		{ "outcome": GoldState.WheelOutcome.FORTUNE_BURST,     "weight": lerp(3.0, 2.0, engine_charge_t) },
		{ "outcome": GoldState.WheelOutcome.GUARANTEED_CRITS,  "weight": lerp(3.0, 4.0, engine_charge_t) },
		{ "outcome": GoldState.WheelOutcome.EXTRA_COINSTORM,   "weight": lerp(2.0, 3.0, engine_charge_t) },
		{ "outcome": GoldState.WheelOutcome.BONUS_MARK,        "weight": minor_w },
	]

	var total:  float = 0.0
	for entry in table:
		total += entry["weight"]

	var roll: float = randf() * total
	var accum: float = 0.0
	for entry in table:
		accum += entry["weight"]
		if roll <= accum:
			return entry["outcome"]

	return GoldState.WheelOutcome.DOUBLE_CRIT   # fallback
