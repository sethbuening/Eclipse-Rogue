# ability_rain_of_crowns.gd
# ---------------------------------------------------------------------------
# NOT on a fixed cooldown.  Instead, Rain of Crowns charges from Fortune
# spent by any Gold ability.  When the charge threshold is met, it places a
# targeting reticle over the densest enemy cluster, then drops a volley of
# massive crowns after a short delay.
#
# Crown impacts leave a persistent crater
#   Each crater behaves like an oversized StaticField — a Gold crit anywhere
#   inside it triggers it.  This means Crowns are a battlefield-shaping tool,
#   not just burst damage.  A well-placed Crown plants a large
#   fortune-triggerable zone that subsequent Gilded Shots / Coinstorms detonate.
#
# Gold synergies
#   ← Midas Curse     : Crowns prioritize the marked enemy's position.
#                       Landing on a marked enemy auto-crits.
#   ← Fortune Engine  : reads GoldState.engine_stacks on impact; consumes
#                       stacks for bonus damage and larger crater radius.
#   ← King's Treasury : Treasury activation sets GoldState.free_crown_pending,
#                       immediately triggering one free Crown volley.
# ---------------------------------------------------------------------------
class_name AbilityRainOfCrowns
extends AbilityData

const CrownScene := preload("res://scenes/abilities/gold_crown.tscn")

# How many crowns fall per volley.
const CROWNS_PER_VOLLEY: int = 3

var _player_ref: CharacterBody2D = null

func tick(context: Dictionary) -> void:
	super.tick(context)
	var player:      Node2D = context["player"]
	var orb_potency: float  = context.get("orb_potency", 1.0)

	_player_ref = player

	var charge_cost: float = get_stat("crowns_charge_cost")
	if charge_cost <= 0.0:
		charge_cost = 150.0

	# Orb glow tracks charge toward next volley.
	context["orb_t"] = clampf(GoldState.crowns_charge / charge_cost, 0.0, 1.0)

	# Fire on charge threshold OR on a free-crown request from Treasury.
	var should_fire: bool = false
	if GoldState.crowns_charge >= charge_cost:
		GoldState.crowns_charge = maxf(0.0, GoldState.crowns_charge - charge_cost)
		should_fire = true
	elif GoldState.free_crown_pending:
		GoldState.free_crown_pending = false
		should_fire = true

	if not should_fire:
		return

	_fire_volley(player, orb_potency)
	context["activated"] = true
	stats.apply_to_player(player)

func _fire_volley(player: Node2D, orb_potency: float) -> void:
	# Target: marked enemy position if active, otherwise densest cluster.
	var target_pos: Vector2 = _find_target_position(player)

	var delay:        float = get_stat("crown_drop_delay")
	if delay <= 0.0:
		delay = 0.6

	var power:        float = stats.get_stat("power",            orb_potency, main_stats)
	var crater_r:     float = stats.get_stat("crown_crater_radius", orb_potency, main_stats)
	if crater_r <= 0.0: crater_r = 72.0

	# Consume Engine stacks for bonus damage and crater size on this volley.
	var engine_stacks:  int   = GoldState.engine_stacks
	GoldState.engine_stacks   = 0
	var engine_damage_bonus:  float = 1.0 + engine_stacks * 0.08
	var engine_crater_bonus:  float = engine_stacks * 2.0

	for i: int in range(CROWNS_PER_VOLLEY):
		# Scatter crowns slightly around the target for area coverage.
		var offset: Vector2 = Vector2(
			randf_range(-24.0, 24.0),
			randf_range(-24.0, 24.0)
		) if i > 0 else Vector2.ZERO

		var crown := CrownScene.instantiate() as Crown
		player.get_parent().add_child(crown)
		crown.global_position = target_pos + offset + Vector2(0, -200)   # drop from above
		crown.setup(
			target_pos + offset,
			delay + i * 0.08,   # stagger impacts
			stats,
			orb_potency,
			main_stats,
			player,
			power * engine_damage_bonus,
			crater_r + engine_crater_bonus
		)

func _find_target_position(player: Node2D) -> Vector2:
	# Prefer the marked enemy.
	if is_instance_valid(GoldState.marked_enemy):
		return GoldState.marked_enemy.global_position

	# Fallback: densest cluster within range (borrow Javelin's approach).
	if EnemyManager.living_enemies.is_empty():
		return player.global_position

	var fire_range: float = get_stat("range")
	if fire_range <= 0.0:
		fire_range = 300.0

	var best_pos:   Vector2 = player.global_position
	var best_count: int     = 0
	const CLUSTER_R:  float = 40.0
	const CLUSTER_R2: float = CLUSTER_R * CLUSTER_R

	for candidate: Enemy in EnemyManager.living_enemies:
		if not is_instance_valid(candidate):
			continue
		if player.global_position.distance_to(candidate.global_position) > fire_range:
			continue
		var count: int = 0
		for other: Enemy in EnemyManager.living_enemies:
			if is_instance_valid(other) and candidate.global_position.distance_squared_to(other.global_position) <= CLUSTER_R2:
				count += 1
		if count > best_count:
			best_count = count
			best_pos   = candidate.global_position

	return best_pos
