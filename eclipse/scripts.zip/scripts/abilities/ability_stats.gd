class_name AbilityStats
extends Resource

# ── core ──────────────────────────────────────────────────────────────────────
@export_group("Core")
@export var power:            float = -1
@export var cooldown:         float = -1
@export var duration:         float = -1
@export var range:            float = -1

# ── speed ─────────────────────────────────────────────────────────────────────
@export_group("Speed")
@export var cast_speed:       float = -1
@export var projectile_speed: float = -1
@export var move_speed_bonus: float = -1

# ── area ──────────────────────────────────────────────────────────────────────
@export_group("Area")
@export var aoe_radius:       float = -1
@export var pierce:           int   = -1

# ── projectiles ───────────────────────────────────────────────────────────────
@export_group("Projectiles")
@export var projectile_count: int   = -1  # number of projectiles fired per cast
@export var chain_length:     int   = -1  # number of times a projectile/effect can chain

# ── critical hits ─────────────────────────────────────────────────────────────
@export_group("Critical Hits")
@export var crit_chance:      float = -1
@export var crit_damage:      float = -1
@export var crit_aoe:         float = -1

# ── mining ────────────────────────────────────────────────────────────────────
@export_group("Mining")
@export var mining_power:     int   = -1
@export var mining_radius:    int   = -1
@export var ore_yield:        float = -1

# ── enemy interaction ─────────────────────────────────────────────────────────
@export_group("Enemy Interaction")
@export var knockback:        float = -1
@export var stun_duration:    float = -1
@export var slow_amount:      float = -1
@export var slow_duration:    float = -1
@export var dot_damage:       float = -1
@export var dot_duration:     float = -1

# ── defensive ─────────────────────────────────────────────────────────────────
@export_group("Defensive")
@export var damage_absorb:    float = -1
@export var reflect_chance:   float = -1
@export var shield_amount:    float = -1
@export var armor_bonus:      int   = -1
@export var armor_pen:        int   = -1

# ── gold ──────────────────────────────────────────────────────────────────────
# These are used exclusively by Gold-metal abilities. Default -1 = unused.
@export_group("Gold")
## Fortune gained per crit (scaled by crit_damage multiplier at runtime).
@export var fortune_per_crit:         float = -1
## Seconds of inactivity before Fortune starts decaying.
@export var fortune_decay_delay:      float = -1
## Fortune lost per second while decaying.
@export var fortune_decay_rate:       float = -1
## Maximum Fortune capacity (used by King's Treasury fill threshold).
@export var fortune_capacity:         float = -1
## How much Fortune fills King's Treasury per point of Fortune generated.
@export var treasury_fill_rate:       float = -1
## Multiplier applied to Coinstorm spread radius at max Fortune.
@export var coinstorm_max_radius_mult: float = -1
## Golden Halo base radius. Scales with Fortune toward halo_max_radius.
@export var halo_min_radius:          float = -1
@export var halo_max_radius:          float = -1
## Fortune Engine: maximum stack cap at zero Fortune. Scales up with Fortune.
@export var engine_base_stack_cap:    int   = -1
## Fortune Engine: additional stacks per 100 Fortune above zero.
@export var engine_stacks_per_fortune: float = -1
## Rain of Crowns: Fortune-spent units required to charge one Crown volley.
@export var crowns_charge_cost:       float = -1
## Rain of Crowns: crater radius left after a Crown impact (StaticField-like).
@export var crown_crater_radius:      float = -1
## Rain of Crowns: delay (seconds) between targeting reticle and impact.
@export var crown_drop_delay:         float = -1
## Jackpot Wheel: interval between wheel spins (seconds).
@export var wheel_spin_interval:      float = -1
## Midas Curse: interval between new marks (seconds) when no mark is active.
@export var curse_mark_interval:      float = -1
## Midas Curse: crit chance increase applied to marked enemy.
@export var curse_crit_chance_bonus:  float = -1
## Midas Curse: crit damage multiplier increase applied to marked enemy.
@export var curse_crit_damage_bonus:  float = -1

# ── helpers ───────────────────────────────────────────────────────────────────
func get_stat(stat_name: String, orb_potency: float = 1.0, main_stats: Array[String] = []) -> float:
	var base: float = get(stat_name)
	if stat_name in main_stats:
		return base * orb_potency
	return base

func roll_crit(player: CharacterBody2D = null) -> bool:
	if player != null and player.guaranteed_crits > 0:
		player.guaranteed_crits -= 1
		return true
	if player == null:
		printerr("[ability_stats.gd] player is null in function roll_crit! Cannot check for guaranteed crits!")
	return randf() < crit_chance

func get_power(is_crit: bool = false) -> float:
	return power * (crit_damage if is_crit else 1.0)

func get_aoe(is_crit: bool = false) -> float:
	return aoe_radius + (crit_aoe if is_crit else 0.0)

func get_armor_pen() -> int:
	return maxi(0, armor_pen)

func apply_to_player(player: CharacterBody2D) -> void:
	if move_speed_bonus != 0.0:
		player.speed += move_speed_bonus
	if armor_bonus > 0:
		player.armor += armor_bonus
