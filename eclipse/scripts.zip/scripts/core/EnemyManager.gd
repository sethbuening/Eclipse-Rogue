# enemy_manager.gd
extends Node

# ── constants ─────────────────────────────────────────────────────────────────

const SEP_CELL:     float = 64.0
const AI_TICK_RATE: float = 1.0 / 20.0
const CULL_MARGIN:  float = 64.0   # pixels beyond screen edge before culling

# ── distance-based AI update tiers ────────────────────────────────────────────
# Enemies far from the player run AI less often. Multiplier is applied to
# AI_TICK_RATE to get the effective tick interval for that tier.
const NEAR_RADIUS_SQ: float = 700.0 * 700.0   # full-rate AI
const FAR_RADIUS_SQ:  float = 1400.0 * 1400.0 # reduced-rate AI
const MID_TIER_MULT:  float = 2.0   # update every ~2x AI_TICK_RATE
const FAR_TIER_MULT:  float = 5.0   # update every ~5x AI_TICK_RATE

# ── object pooling ─────────────────────────────────────────────────────────────
const MAX_POOL_SIZE_PER_TYPE: int = 64

# String (EnemyData id) → Array[Enemy] of inactive, pooled instances ready for reuse.
var _pool: Dictionary = {}

# ── public state ──────────────────────────────────────────────────────────────

var living_enemies: Array[Enemy] = []
var player:         CharacterBody2D
var tilemap:        Node = null

# set of enemies currently offscreen — read by enemy.gd in tick_ai
var offscreen_enemies: Dictionary = {}

## When true (toggled by dev_mode), all enemy children stay visible
## regardless of on-screen culling — useful for debugging spawn logic.
var debug_force_visible: bool = false

signal enemy_died(enemy: Enemy)

# ── private state ─────────────────────────────────────────────────────────────

var _sep_grid: Dictionary = {}
var _ai_accum: float      = 0.0
var _camera:   Camera2D   = null

# ── process ───────────────────────────────────────────────────────────────────

func _process(delta: float) -> void:
	_update_visibility()

	for enemy in living_enemies:
		if is_instance_valid(enemy):
			enemy.tick_move(delta, offscreen_enemies.has(enemy))

	_ai_accum += delta
	if _ai_accum < AI_TICK_RATE:
		return

	var ai_delta: float = _ai_accum
	_ai_accum = 0.0
	_build_sep_grid()

	var player_pos: Vector2 = player.global_position if player != null else Vector2.ZERO

	for enemy in living_enemies:
		if not is_instance_valid(enemy):
			continue

		# Determine this enemy's AI tier based on distance to the player.
		var d_sq: float = enemy.global_position.distance_squared_to(player_pos)
		var tier_mult: float
		if d_sq <= NEAR_RADIUS_SQ:
			tier_mult = 1.0
		elif d_sq <= FAR_RADIUS_SQ:
			tier_mult = MID_TIER_MULT
		else:
			tier_mult = FAR_TIER_MULT

		enemy._ai_accum += ai_delta
		var interval: float = AI_TICK_RATE * tier_mult
		if enemy._ai_accum < interval:
			continue

		var enemy_ai_delta: float = enemy._ai_accum
		enemy._ai_accum = 0.0
		enemy.tick_ai(enemy_ai_delta)

# ── visibility culling ────────────────────────────────────────────────────────

func _update_visibility() -> void:
	offscreen_enemies.clear()
	var vp_size: Vector2     = get_viewport().get_visible_rect().size
	var transform: Transform2D = get_viewport().get_canvas_transform()

	for enemy in living_enemies:
		if not is_instance_valid(enemy):
			continue
		var screen_pos: Vector2 = transform * enemy.global_position
		var on_screen: bool = screen_pos.x > -CULL_MARGIN \
						  and screen_pos.x < vp_size.x + CULL_MARGIN \
						  and screen_pos.y > -CULL_MARGIN \
						  and screen_pos.y < vp_size.y + CULL_MARGIN
		if not on_screen:
			offscreen_enemies[enemy] = true
		var show: bool = on_screen or debug_force_visible
		for child in enemy.get_children():
			if child is Node2D:
				child.visible = show

# ── separation grid ───────────────────────────────────────────────────────────

func _build_sep_grid() -> void:
	_sep_grid.clear()
	for enemy in living_enemies:
		if not is_instance_valid(enemy):
			continue
		var cell := Vector2i(
			int(floor(enemy.global_position.x / SEP_CELL)),
			int(floor(enemy.global_position.y / SEP_CELL))
		)
		if not _sep_grid.has(cell):
			_sep_grid[cell] = []
		_sep_grid[cell].append(enemy)

func get_nearby_enemies(pos: Vector2, radius: float) -> Array:
	var result:      Array = []
	var cell_radius: int   = int(ceil(radius / SEP_CELL)) + 1
	var origin := Vector2i(
		int(floor(pos.x / SEP_CELL)),
		int(floor(pos.y / SEP_CELL))
	)
	for dx in range(-cell_radius, cell_radius + 1):
		for dy in range(-cell_radius, cell_radius + 1):
			var bucket = _sep_grid.get(origin + Vector2i(dx, dy), null)
			if bucket == null:
				continue
			for e in bucket:
				if is_instance_valid(e):
					result.append(e)
	return result

# ── spawning ──────────────────────────────────────────────────────────────────

func spawn_squad(squad: Array[EnemyData], modifier: Util.Modifier) -> void:
	for d: EnemyData in squad:
		spawn_enemy(d, modifier)

func spawn_enemy(data: EnemyData, modifier: Util.Modifier = Util.Modifier.NONE) -> void:
	if data.scene == null:
		push_error("[EnemyManager] '%s' has no scene assigned." % data.id)
		return

	var enemy: Enemy = _acquire_pooled(data)
	if enemy == null:
		enemy      = data.scene.instantiate()
		enemy.data = data
		enemy.tilemap = tilemap
		enemy.died.connect(_on_enemy_died)
		add_child(enemy)
		enemy.setup(AI_TICK_RATE)
	else:
		enemy.data    = data
		enemy.tilemap = tilemap
		enemy._ai_accum = 0.0
		for child in enemy.get_children():
			if child is Node2D:
				child.visible = true

	enemy.initialize(player, modifier)
	living_enemies.append(enemy)

## Returns a pooled, deactivated instance matching [data]'s id, or null if
## none is available. Pooled instances remain in the scene tree (still
## children of EnemyManager) but are hidden and excluded from living_enemies.
func _acquire_pooled(data: EnemyData) -> Enemy:
	if not _pool.has(data.id):
		return null
	var bucket: Array = _pool[data.id]
	if bucket.is_empty():
		return null
	var enemy: Enemy = bucket.pop_back()
	if not is_instance_valid(enemy):
		return _acquire_pooled(data)
	return enemy

## Returns [enemy] to the pool for its EnemyData id rather than freeing it.
## Falls back to queue_free() if the pool for that type is already full, or
## if the enemy is a special subclass (e.g. E_Angel, E_Pylon) that manages
## extra child nodes / cross-references unsafe to reuse via pooling.
func _release_to_pool(enemy: Enemy) -> void:
	var script: Script = enemy.get_script()
	if script != null and script.get_global_name() != &"Enemy" and script.get_global_name() != "":
		enemy.queue_free()
		return

	var id: String = enemy.data.id if enemy.data else ""
	if id == "":
		enemy.queue_free()
		return

	var bucket: Array
	if _pool.has(id):
		bucket = _pool[id]
	else:
		bucket = []
		_pool[id] = bucket

	if bucket.size() >= MAX_POOL_SIZE_PER_TYPE:
		enemy.queue_free()
		return

	enemy.deactivate()
	bucket.append(enemy)

func register_enemy(enemy: Enemy) -> void:
	if living_enemies.has(enemy):
		return
	enemy.died.connect(_on_enemy_died)
	living_enemies.append(enemy)

func unregister_enemy(enemy: Enemy) -> void:
	living_enemies.erase(enemy)

# ── lifecycle ─────────────────────────────────────────────────────────────────

func clear_all() -> void:
	for enemy: Enemy in living_enemies:
		if is_instance_valid(enemy):
			_release_to_pool(enemy)
	living_enemies.clear()

func on_level_changed() -> void:
	clear_all()
	# Pooled enemies persist across levels; free them too since their
	# EnemyData/tilemap references become stale.
	for id: String in _pool:
		for enemy: Enemy in _pool[id]:
			if is_instance_valid(enemy):
				enemy.queue_free()
	_pool.clear()

func _on_enemy_died(enemy: Enemy) -> void:
	living_enemies.erase(enemy)
	emit_signal("enemy_died", enemy)
	_release_to_pool(enemy)
